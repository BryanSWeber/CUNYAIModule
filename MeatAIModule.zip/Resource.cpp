#pragma once

#include <BWAPI.h>
#include "Source\Resource.h"
#include "Source\Worker.h"
#include "Source\MeatAIModule.h"


// Set the money value of a resource.
void Resource::setMoney( BWAPI::Unit r ) {
    if ( r->getType().isResourceContainer() || r->getType().isRefinery() ) { // might be redundant but better safe than sorry.
        int money = r->getResources();
        if ( r->getType().isMineralField() ) {
            _mincount = money;
        }
        else if ( r->getType().isRefinery() ) {
            _gascount = money;
        }
    }
};

// Set the distance to the closest base. Should be called upon each hatchery and death.
void Resource::setDist( BWAPI::Unit r ) {
    _distbase = r->getDistance( r->getClosestUnit( BWAPI::Filter::IsResourceDepot && BWAPI::Filter::IsOwned ) );
}

// Define a resource, expected usage: upon discovery.
void Resource::setResource( BWAPI::Unit r ) {
    if ( r->getType().isResourceContainer() || r->getType().isRefinery() ) { // might be redundant but better safe than sorry.
        BWAPI::Position location = r->getPosition();
        setMoney( r );
    }
    else {
        BWAPI::Broodwar->sendText( "Hey, I'm not a resource. Don't assign me to the Resource Subclass." );
    }
};

// Get the closest unoccupied worker.
void Resource::getWorker() {
    // TBA
};

// Return the remaining stock of assets in this d.
int Resource::getMoney() {
    return _mincount > _gascount ? _mincount : _gascount;
};

int Resource::getActiveWorkers() {
    return _activeworkers;
};

// The closest resource depot upon discovery.
int Resource::getDist() {
    return _distbase;
};
