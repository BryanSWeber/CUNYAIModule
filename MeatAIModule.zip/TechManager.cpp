#pragma once
// Remember not to use "Broodwar" in any global class constructor!
# include "Source\MeatAIModule.h"

using namespace BWAPI;

// Returns true if there are any new technology improvements available at this time (new buildings, upgrades, researches, mutations).
bool MeatAIModule::Tech_Avail() {

    bool avail = false;

    for ( auto & u : BWAPI::Broodwar->self()->getUnits() ) {

        if ( u->getType() == BWAPI::UnitTypes::Zerg_Drone ) {
            bool long_condition = (u->canBuild( BWAPI::UnitTypes::Zerg_Spawning_Pool ) && Count_Units( BWAPI::UnitTypes::Zerg_Spawning_Pool ) == 0) ||
                    (u->canBuild( BWAPI::UnitTypes::Zerg_Evolution_Chamber ) && Count_Units( BWAPI::UnitTypes::Zerg_Evolution_Chamber ) < 2) ||
                    (u->canBuild( BWAPI::UnitTypes::Zerg_Hydralisk_Den ) && Count_Units( BWAPI::UnitTypes::Zerg_Hydralisk_Den ) == 0)||
                    (u->canBuild( BWAPI::UnitTypes::Zerg_Spire ) && Count_Units( BWAPI::UnitTypes::Zerg_Spire ) == 0) ||
                    (u->canBuild( BWAPI::UnitTypes::Zerg_Queens_Nest ) && Count_Units( BWAPI::UnitTypes::Zerg_Queens_Nest ) == 0) ||
                    (u->canBuild( BWAPI::UnitTypes::Zerg_Ultralisk_Cavern ) && Count_Units( BWAPI::UnitTypes::Zerg_Ultralisk_Cavern ) == 0);
            if ( long_condition ) {
                avail = true;
            }
        }
        else if ( u->getType().isSuccessorOf(BWAPI::UnitTypes::Zerg_Hatchery) && !u->isUpgrading() && !u->isMorphing() ) {
            bool long_condition = (u->canMorph( BWAPI::UnitTypes::Zerg_Lair ) && Count_Units( BWAPI::UnitTypes::Zerg_Lair ) == 0 && Count_Units( BWAPI::UnitTypes::Zerg_Hive ) == 0) ||
                    (u->canMorph( BWAPI::UnitTypes::Zerg_Hive ) && Count_Units( BWAPI::UnitTypes::Zerg_Hive ) == 0);
            if ( long_condition ) {
                avail = true;
            }
        }
        else if ( u->getType().isBuilding() && !u->isUpgrading() && !u->isMorphing() && !u->isBeingConstructed() ){ // check idle buildings for potential upgrades.
            for ( int i = 0; i != 12; i++ )
            { // iterating through the main upgrades we have available and MeatAI "knows" about. 
                int known_ups[11] = { 3, 10, 11, 25, 26, 27, 28, 29, 30, 52, 53 }; // Identifies zerg upgrades of that we have initialized at this time. See UpgradeType definition for references.
                BWAPI::UpgradeType up_current = (BWAPI::UpgradeType) known_ups[i];
                BWAPI::UpgradeType::set building_up_set = u->getType().upgradesWhat(); // does this idle building make that upgrade?
                if ( building_up_set.find( up_current ) != building_up_set.end() ) {
                    if ( BWAPI::Broodwar->self()->getUpgradeLevel( up_current ) < up_current.maxRepeats() && !BWAPI::Broodwar->self()->isUpgrading( up_current ) ) { // if it is not maxed, and nothing is upgrading it, then there must be some tech work we could do.
                        avail = true;
                    }
                }
            }
        } // if condition
    }// for every unit

    return avail;
}

void MeatAIModule::Tech_Begin(Unit building) {

    Check_N_Upgrade( UpgradeTypes::Metabolic_Boost, building, true );
    Check_N_Upgrade( UpgradeTypes::Zerg_Carapace, building, true );
    Check_N_Upgrade( UpgradeTypes::Muscular_Augments, building, true );
    Check_N_Upgrade( UpgradeTypes::Grooved_Spines, building, true );
    Check_N_Upgrade( UpgradeTypes::Zerg_Melee_Attacks, building, true );
    Check_N_Upgrade( UpgradeTypes::Zerg_Missile_Attacks, building, Stock_Units(UnitTypes::Zerg_Zergling) > Stock_Units(UnitTypes::Zerg_Hydralisk) || BWAPI::Broodwar->self()->getUpgradeLevel( UpgradeTypes::Zerg_Melee_Attacks ) == 3 );

    Check_N_Build( UnitTypes::Zerg_Lair, building, (tech_starved) &&
        Count_Units( UnitTypes::Zerg_Lair ) == 0 &&
        Count_Units( UnitTypes::Zerg_Evolution_Chamber ) > 0 &&
        Count_Units( UnitTypes::Zerg_Hive ) == 0 &&//don't need lair if we have a hive.
        building->getType() == UnitTypes::Zerg_Hatchery );

    Check_N_Upgrade( UpgradeTypes::Pneumatized_Carapace, building, Count_Units( UnitTypes::Zerg_Lair ) > 0 || Count_Units( UnitTypes::Zerg_Hive ) > 0 );
    Check_N_Upgrade( UpgradeTypes::Antennae, building, Count_Units( UnitTypes::Zerg_Lair ) > 0 || Count_Units( UnitTypes::Zerg_Hive ) > 0 ); //don't need lair if we have a hive.

    Check_N_Build( UnitTypes::Zerg_Hive, building, (tech_starved) &&
        Count_Units( UnitTypes::Zerg_Queens_Nest ) >= 0 &&
        building->getType() == UnitTypes::Zerg_Lair &&
        Count_Units( UnitTypes::Zerg_Hive ) == 0 ); //If you're tech-starved at this point, don't make random hives.

    Check_N_Upgrade( UpgradeTypes::Adrenal_Glands, building, Count_Units( UnitTypes::Zerg_Hive ) > 0 );
    Check_N_Upgrade( UpgradeTypes::Anabolic_Synthesis, building, Count_Units( UnitTypes::Zerg_Ultralisk_Cavern ) > 0 );
    Check_N_Upgrade( UpgradeTypes::Chitinous_Plating, building, Count_Units( UnitTypes::Zerg_Ultralisk_Cavern ) > 0 );
}


//Zerg_Carapace = 3,
//Zerg_Melee_Attacks = 10,
//Zerg_Missile_Attacks = 11,
//Antennae = 25,
//Pneumatized_Carapace = 26,
//Metabolic_Boost = 27,
//Adrenal_Glands = 28,
//Muscular_Augments = 29,
//Grooved_Spines = 30,
//Chitinous_Plating = 52,
//Anabolic_Synthesis = 53,