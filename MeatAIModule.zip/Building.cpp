# include "Source\MeatAIModule.h"

using namespace BWAPI;
using namespace Filter;
using namespace std;

void MeatAIModule::Expo(Unit unit) {
    Unitset resource_grps = Broodwar->getMinerals();
    double dist = 999999;
        double* dist_ptr = &dist;
    int expo_x;
        int* expo_x_ptr = &expo_x;
    int expo_y;
        int* expo_y_ptr = &expo_y;
    if ( !resource_grps.empty() ) {

        for ( auto expo = resource_grps.begin(); expo != resource_grps.end(); ++expo ) { // search for closest resource group. They are our potential expos.

            if ( (*expo) && (*expo)->exists() ) {

                int expo_x_px_temp = (*expo)->getPosition().x;
                int expo_y_px_temp = (*expo)->getPosition().y;

                Broodwar->drawCircleMap( expo_x_px_temp, expo_y_px_temp, 250, Colors::Cyan );

                TilePosition buildPosition = Broodwar->getBuildLocation( UnitTypes::Zerg_Hatchery, { expo_x_px_temp / 32 , expo_y_px_temp / 32 }, 50 );  // Find a suitible build location within 50 tiles.

                if ( buildPosition.isValid() ) {

                    Unitset bases = Broodwar->getUnitsInRadius( buildPosition.x*32, buildPosition.y*32, 500, Filter::IsResourceDepot && Filter::IsOwned );
                    Unitset r_check = Broodwar->getUnitsInRadius( buildPosition.x * 32, buildPosition.y * 32, 250, Filter::ResourceGroup );

                    if ( bases.empty() && r_check.size() >= 4 ) { // check if there are NO bases with 500p of this resource center, AND 4+ resources are inside 250p.
                        for ( auto r = r_check.begin(); r != r_check.end() && !r_check.empty(); ++r ) {
                            if ( (*r) && (*r)->exists() ) {
                                double dist_temp = unit->getDistance( { expo_x_px_temp, expo_y_px_temp } ); //getDistance is not overloaded for tile positions
                                if ( dist_temp < dist ) {
                                    *dist_ptr = dist_temp;  // if it is closer, but not immediately next to our main, update the new closest distance.
                                    *expo_x_ptr = buildPosition.x;
                                    *expo_y_ptr = buildPosition.y; // must use tile locations.
                                } // set expo location
                            } // Closure confirm existance of nearby resources
                        } // closure confirm 4+ resources nearby
                    } // closure Look through all viable bases.
                } // closure from each valid build position.
            } // Closure confirm existance of any resource group.
        }// closure: loop through all resource groups.
    }//closure search through all resource groups.

    TilePosition finalbuildPosition = Broodwar->getBuildLocation( UnitTypes::Zerg_Hatchery, { expo_x , expo_y }, 50 );  // build the expo near the selection we have chosen, within 50 tiles.
    unit->build( UnitTypes::Zerg_Hatchery, finalbuildPosition );
    PrintError_Unit( unit );
    t_build += 125; // give extra long time to get to that position.
}