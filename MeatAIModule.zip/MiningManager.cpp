#pragma once
# include "Source\MeatAIModule.h"

using namespace BWAPI;
using namespace Filter;
using namespace std; 


//Builds an expansion. Buggy. Depends on full vision of the build site, no recognition of past build sites.
void MeatAIModule::Expo( Unit unit, bool extra_critera ) {
    if ( Broodwar->self()->minerals() >= 300 && extra_critera ) {
        int dist = 999999;
        size_t local_min_threshold = 3;
        int build_order = false;
        Unitset gas_set = Broodwar->getStaticGeysers();
        Unitset min_set = Broodwar->getStaticMinerals();
            min_set.insert( gas_set.begin(), gas_set.end() );
            for ( auto min = min_set.begin(); min != min_set.end(); ++min ) { // search for closest resource group. They are our potential expos.

                if ( (*min) && (*min)->exists() ) {

                    TilePosition min_pos_t = (*min)->getTilePosition();

                    for ( auto tile_x = min_pos_t.x - 8; tile_x != min_pos_t.x + 8; ++tile_x ) {
                        for ( auto tile_y = min_pos_t.y - 8; tile_y != min_pos_t.y + 8; ++tile_y ) { //my math says x-7 and x+4, and y-6 and y+7 are the last funtional build locations, since hatcheries are 4x3.  My math is pointless, use the CPU to check.

                            if ( tile_x >= min_pos_t.x + 3 || tile_x <= min_pos_t.x - 3 ||
                                 tile_y >= min_pos_t.y + 3 || tile_y <= min_pos_t.y - 3 ) {

                                bool buildable = Broodwar->canBuildHere( { tile_x, tile_y }, UnitTypes::Zerg_Hatchery, unit );

                                Position center = { tile_x * 32 + UnitTypes::Zerg_Hatchery.dimensionLeft() , tile_y * 32 + UnitTypes::Zerg_Hatchery.dimensionUp() }; // The build location is upper left tile of the building. The true center is further along in both x and y dimensions. The upper left tile is 0,0. 

                                if ( buildable && _ANALYSIS_MODE ) {
                                    Broodwar->drawCircleMap( center, 10, Colors::Green );
                                }
                                else {
                                    Broodwar->drawCircleMap( center, 10, Colors::Red );
                                }

                                int walk = unit->getDistance( center );

                                Unitset bases = Broodwar->getUnitsInRadius( center, 500, IsResourceDepot && IsOwned );
                                Unitset local_min = Broodwar->getUnitsInRadius( center, 224, IsRefinery || IsResourceContainer ); //includes gas now. 96 pixels is minimum distance, you also must leave the body of the hatchery, so about 96+32*4 pixels should work. Will be too distant if vertically above or below the mineral line. Left-right is ok though.

                                if ( buildable && bases.empty() && ( local_min.size() > local_min_threshold || ( walk < dist && local_min.size() == local_min_threshold) ) ) { // if it is better, or equally good and closer.
                                    local_min_threshold = local_min.size(); // the most minerals.
                                    dist = walk;  // a tolarable walk to the expo.
                                    unit->build( UnitTypes::Zerg_Hatchery, { tile_x, tile_y } );
                                    build_order = true;
                                }
                            }
                        }
                    }
                }
            }

        if ( build_order )
        {
            t_build += 150;
        }

    }
}

//Sends a worker to mine minerals.
void MeatAIModule::Worker_Mine( Unit unit ) {

    if ( isIdleEmpty( unit ) ) {
        Unit anchor_min = unit->getClosestUnit( IsMineralField );
        if ( anchor_min && anchor_min->exists() ) {
            unit->gather( anchor_min ); // if you are idle, get to work.
        }
    } // stopgap command.

    Unit local_base = unit->getClosestUnit( IsResourceDepot && IsOwned && IsCompleted );

    if ( local_base && local_base->exists() ) {

            Unitset local_sat = local_base->getUnitsInRadius( 250, IsWorker && (IsGatheringMinerals || IsCarryingMinerals) );
            Unitset local_min = local_base->getUnitsInRadius( 250, IsMineralField );
            int local_dist = unit->getDistance( local_base );

            bool acceptable_local = local_dist < 500 && (int)local_sat.size() < (int)local_min.size() * 1.75; // if local conditions are fine (and you are working), continue, no commands.

            if ( !acceptable_local && rand() % 100 + 1 < 25 ) { // if local conditions are bad, we will consider tranfering 25% of these workers elsewhere.
                Unitset bases = unit->getUnitsInRadius( 999999, IsResourceDepot && IsOwned );

                int nearest_dist = 9999999;
                for ( auto base = bases.begin(); base != bases.end() && !bases.empty(); ++base ) {
                    if ( (*base)->exists() ) {
                        int dist = unit->getDistance( *base );

                        Unitset base_sat = (*base)->getUnitsInRadius( 500, IsWorker && (IsGatheringMinerals || IsCarryingMinerals) );
                        Unitset base_min = (*base)->getUnitsInRadius( 500, IsMineralField );
                        bool acceptable_foreign = !base_min.empty() && (int)base_sat.size() < (int)base_min.size(); // there must be a severe desparity to switch, and please only switch to ones clearly different than your local mine, 250 p.

                        if ( dist > 750 && dist < nearest_dist && acceptable_foreign) {
                            nearest_dist = dist; // transfer to the nearest undersaturated base.
                                Unit anchor_min = (*base)->getClosestUnit( IsMineralField );
                                if ( anchor_min && anchor_min->exists() ) {
                                    unit->gather( anchor_min );
                                }// closure act of transferring drones themselves.
                        } // closure for base being a canidate for transfer.
                    } // closure for base existance.
                } // iterate through all possible bases
            } // closure for worker transfer
        } // closure safety check for existance of local base.
} // closure worker mine

//Sends a Worker to gather Gas.
void MeatAIModule::Worker_Gas( Unit unit ) {

    if ( isIdleEmpty( unit ) ) {
        Unit anchor_gas = unit->getClosestUnit( IsRefinery );
        if ( anchor_gas && anchor_gas->exists() ) {
            unit->gather( anchor_gas ); // if you are idle, get to work.
        }
    } // stopgap command.

    Unit local_base = unit->getClosestUnit( IsResourceDepot && IsOwned && IsCompleted );

    if ( local_base && local_base->exists() ) {

        Unitset local_gas = local_base->getUnitsInRadius( 250, IsWorker && (IsGatheringGas || IsCarryingGas) );
        Unitset local_refinery = local_base->getUnitsInRadius( 250, IsRefinery );
        int local_dist = unit->getDistance( local_base );

        bool acceptable_local = local_dist < 500 && (int)local_gas.size() <= (int)local_refinery.size() * 3; // if local conditions are fine (and you are working), continue, no commands.

        if ( !acceptable_local && rand() % 100 + 1 < 25 ) { // if local conditions are bad, we will consider tranfering 25% of these workers elsewhere.
            Unitset bases = unit->getUnitsInRadius( 999999, IsResourceDepot && IsOwned );
            int nearest_dist = 9999999;

            for ( auto base = bases.begin(); base != bases.end() && !bases.empty(); ++base ) {
                if ( (*base)->exists() ) {
                    int dist = unit->getDistance( *base );

                        Unitset base_gas = (*base)->getUnitsInRadius( 500, IsWorker && (IsGatheringGas || IsCarryingGas) );
                        Unitset base_refinery = (*base)->getUnitsInRadius( 500, IsRefinery );
                        bool acceptable_foreign = !base_refinery.empty() && (int)base_gas.size() <= (int)base_refinery.size(); // there must be a severe desparity to switch, and please only switch to ones clearly different than your local mine, 250 p.

                        if ( dist > 750 && dist < nearest_dist && acceptable_foreign ) {
                            nearest_dist = dist; // transfer to the nearest undersaturated base.
                            Unit anchor_gas = (*base)->getClosestUnit( IsRefinery );
                            if ( anchor_gas && anchor_gas->exists() ) {
                                unit->gather( anchor_gas );
                            }
                        } // closure act of transferring drones themselves.
                } // closure for base existance.
            } // iterate through all possible bases
        } // closure for worker transfer
    } // closure safety check for existance of local base.
} // closure worker mine

//Returns True if there is an out for gas. Does not consider all possible gas outlets.
bool MeatAIModule::Gas_Outlet() {
    bool outlet_avail = false;

    if ( MeatAIModule::Tech_Avail() && Count_Units( BWAPI::UnitTypes::Zerg_Spawning_Pool ) > 0 && tech_starved ) {
        outlet_avail = true;
    }

    for ( auto & u : BWAPI::Broodwar->self()->getUnits() ) {
        if ( u->getType()== UnitTypes::Zerg_Larva ) {
            bool long_condition = u->canTrain( UnitTypes::Zerg_Hydralisk ) ||
                           u->canTrain( UnitTypes::Zerg_Mutalisk ) ||
                           u->canTrain( UnitTypes::Zerg_Ultralisk );
            if ( long_condition ) {
                outlet_avail = true;
            }
        }
    }

    return outlet_avail;
}

