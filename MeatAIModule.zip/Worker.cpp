#pragma once

#include <BWAPI.h>
#include "Source\Resource.h"
#include "Source\MeatAIModule.h"

// Set this worker's current task. Does not set location of mine or destination atm.
void Worker::setWorker( BWAPI::Unit u ) {
    if ( u->getType().isWorker() ) {
        if ( u->isGatheringGas() || u->isCarryingGas() ) {
            _gasworker = true;
        }
        else if ( u->isGatheringMinerals() || u->isCarryingMinerals() ) {
            _minworker = true;
        }
        else if ( u->isMorphing() || u->getOrder() == BWAPI::Orders::ZergBuildingMorph ) {
            _builder = true;
        }
    }
    else {
        BWAPI::Broodwar->sendText( "Hey, I'm not a Worker. Don't assign me to the worker subclass." );
    }
};

// Name this carefully chosen Resource as the worker's target.
void Worker::setAttached_Resource( BWAPI::Unit r ) {
    if ( r->getType().isResourceContainer() || r->getType().isRefinery() ) {
        _attached_resource = r;
    }
    else {
        BWAPI::Broodwar->sendText( "Hey, I'm not a Resource. Don't attach me to the worker subclass." );
    }
};

//Name this carefully chosen Base as the worker's target.
void Worker::setAttached_Base( BWAPI::Unit base ) {
    if ( base->getType().isResourceDepot() ) {
        _attached_base = base;
    }
    else {
        BWAPI::Broodwar->sendText( "Hey, I'm not a Base. Don't attach me to the worker subclass." );
    }
};