#pragma once
#include "Source\MeatAIModule.h"

using namespace BWAPI;
using namespace Filter;
using namespace std;

//Checks if a building can be built, and passes additional boolean criteria.  If all critera are passed, then it builds the building and delays the building timer 25 frames, or ~1 sec. It may now allow morphing, eg, lair, hive and lurkers, but this has not yet been tested.  It now has an extensive creep colony script that prefers centralized locations.
void MeatAIModule::Check_N_Build( UnitType building, Unit unit, bool extra_critera )
{
    if ( unit->canBuild( building ) &&
        Broodwar->self()->minerals() >= building.mineralPrice() &&
        Broodwar->self()->gas() >= building.gasPrice() &&
        extra_critera &&
        building != UnitTypes::Zerg_Creep_Colony )
    {
        TilePosition buildPosition = Broodwar->getBuildLocation( building, unit->getTilePosition(), 64, building == UnitTypes::Zerg_Creep_Colony );
        unit->build( building, buildPosition );
        t_build += 25;
    }
    else if ( unit->canBuild( building ) &&
        Broodwar->self()->minerals() >= building.mineralPrice() &&
        Broodwar->self()->gas() >= building.gasPrice() &&
        extra_critera &&
        building == UnitTypes::Zerg_Creep_Colony ) {

        Unitset base_core = unit->getUnitsInRadius( 99999, IsBuilding && IsResourceDepot && IsCompleted );
        int middle_x = Broodwar->mapWidth() / 2 * 32;
        int middle_y = Broodwar->mapHeight() / 2 * 32;

        int central_base_x = 0;
        int central_base_y = 0;

        int furth_x_dist = 0;
        int furth_y_dist = 0;

        if ( !base_core.empty() ) {

            for ( auto base = base_core.begin(); base != base_core.end(); ++base ) {

                int x_dist = pow( middle_x - (*base)->getPosition().x, 2 );
                int y_dist = pow( middle_y - (*base)->getPosition().y, 2 );

                int new_dist = sqrt( (double)x_dist + (double)y_dist );

                int furth_x_dist = pow( middle_x - central_base_x, 2 );
                int furth_y_dist = pow( middle_y - central_base_y, 2 );

                int old_dist = sqrt( (double)furth_x_dist + (double)furth_y_dist );

                if ( new_dist <= old_dist ) {
                    central_base_x = (*base)->getPosition().x;
                    central_base_y = (*base)->getPosition().y;
                }
            }
        }
        double theta = atan2( middle_y - central_base_y, middle_x - central_base_x );
        int adj_dx = cos( theta ) * 4; // move n tiles closer to the center of the map.
        int adj_dy = sin( theta ) * 4;

        TilePosition buildPosition = Broodwar->getBuildLocation( building, { central_base_x / 32 + adj_dx , central_base_y / 32 + adj_dy }, 5 );
        unit->build( building, buildPosition );
        t_build += 25;
    }

    if ( unit->canMorph( building ) &&
        Broodwar->self()->minerals() >= building.mineralPrice() &&
        Broodwar->self()->gas() >= building.gasPrice() &&
        extra_critera )
    {
        unit->morph( building );
        t_build += 25;
    }
}

//Checks if an upgrade can be built, and passes additional boolean criteria.  If all critera are passed, then it performs the upgrade. Requires extra critera.
void MeatAIModule::Check_N_Upgrade( UpgradeType ups, Unit unit, bool extra_critera )
{
    if ( unit->canUpgrade( ups ) &&
        Broodwar->self()->minerals() >= ups.mineralPrice() &&
        Broodwar->self()->gas() >= ups.gasPrice() &&
        extra_critera ) {
        unit->upgrade( ups );
    }
}

//Checks if a unit can be built from a larva, and passes additional boolean criteria.  If all critera are passed, then it performs the upgrade. Requires extra critera.
void MeatAIModule::Check_N_Grow( UnitType unittype, Unit larva, bool extra_critera )
{
    if ( larva->canTrain( unittype ) &&
        Broodwar->self()->minerals() >= unittype.mineralPrice() &&
        Broodwar->self()->gas() >= unittype.gasPrice() &&
        extra_critera )
    {
        larva->train( unittype );
    }
}

//Creates a new unit. Reflects (poorly) upon enemy units in enemy_set. Incomplete.
void MeatAIModule::Reactive_Build( Unit drone, Unitset enemy_set )
{

    //Tally up crucial details about enemy. Should be doing this onclass. Perhaps make an enemy summary class?
    int fliers = 0;
    int cannot_shoot_up = 0;
    int high_ground = 0;
    int e_count = 0;

    if ( !enemy_set.empty() ) {
        for ( auto e = enemy_set.begin(); e != enemy_set.end() && !enemy_set.empty(); e++ ) { // trims the set for each attackable enemy. We move towards the center of these units
            if ( (*e)->isFlying() ) {
                fliers++;
            }
            if ( (*e)->getType().airWeapon() == WeaponTypes::None ) {
                cannot_shoot_up++;
            }
            Region r = (*e)->getRegion();
            if ( r ) {
                if ( r->isHigherGround() ) {
                    high_ground++;
                }
            }
            e_count++;
        }
    }

    //Army build/replenish.  Cycle through military units available.
    if ( fliers > 0.05 * e_count ) { // Mutas generally sucks against air unless properly massed and manuvered (which mine are not)
        Check_N_Grow( UnitTypes::Zerg_Scourge, drone, army_starved && Count_Units( UnitTypes::Zerg_Spire ) > 0 && Count_Units( UnitTypes::Zerg_Scourge ) < 5 ); // hard cap on scourges, they build 2 at a time. If you have 10 scourge you're probably saving them or something is wrong.
        Check_N_Grow( UnitTypes::Zerg_Hydralisk, drone, army_starved && Count_Units( UnitTypes::Zerg_Hydralisk_Den ) > 0 );
    } else if ( high_ground > 0.25 * e_count ) { // if we have to go through a choke, this is all we want. Save for them.
        Check_N_Grow( UnitTypes::Zerg_Ultralisk, drone, army_starved && Count_Units( UnitTypes::Zerg_Ultralisk_Cavern ) > 0 );
        Check_N_Grow( UnitTypes::Zerg_Mutalisk, drone, army_starved && Count_Units( UnitTypes::Zerg_Spire ) > 0 );
    } else if ( cannot_shoot_up > 0.25 * e_count ) {
        Check_N_Grow( UnitTypes::Zerg_Mutalisk, drone, army_starved && Count_Units( UnitTypes::Zerg_Spire ) > 0 );
    } else {
        Check_N_Grow( UnitTypes::Zerg_Ultralisk, drone, army_starved && Count_Units( UnitTypes::Zerg_Ultralisk_Cavern ) > 0 );
        Check_N_Grow( UnitTypes::Zerg_Hydralisk, drone, army_starved && Count_Units( UnitTypes::Zerg_Hydralisk_Den ) > 0 );
        Check_N_Grow( UnitTypes::Zerg_Zergling, drone, army_starved && Count_Units( UnitTypes::Zerg_Spawning_Pool ) > 0 );
    }

}

//Creates a new building with DRONE. Incomplete.
void MeatAIModule::Building_Begin( Unit drone ) {

    //Expo loop, whenever not army starved. 
    Expo( drone, !army_starved );

    //Basic Buildings
    Check_N_Build( UnitTypes::Zerg_Spawning_Pool, drone, !econ_starved &&
        Count_Units( UnitTypes::Zerg_Spawning_Pool ) == 0 );

    //Tech Buildings
    Check_N_Build( UnitTypes::Zerg_Evolution_Chamber, drone, tech_starved &&
        Count_Units( UnitTypes::Zerg_Evolution_Chamber ) < 2 && // This has resolved our issues with 4x evo chambers
        Count_Units( UnitTypes::Zerg_Spawning_Pool ) > 0 );

    Check_N_Build( UnitTypes::Zerg_Hydralisk_Den, drone, tech_starved &&
        Count_Units( UnitTypes::Zerg_Spawning_Pool ) > 0 &&
        Count_Units( UnitTypes::Zerg_Hydralisk_Den ) == 0 );

    Check_N_Build( UnitTypes::Zerg_Spire, drone, tech_starved &&
        Count_Units( UnitTypes::Zerg_Spire ) == 0 &&
        Count_Units( UnitTypes::Zerg_Lair ) >= 0 );

    Check_N_Build( UnitTypes::Zerg_Queens_Nest, drone, tech_starved &&
        Count_Units( UnitTypes::Zerg_Queens_Nest ) == 0 &&
        Count_Units( UnitTypes::Zerg_Lair ) >= 0 &&
        Count_Units( UnitTypes::Zerg_Spire ) >= 0 );  // Spires are expensive and it will probably skip them unless it is floating a lot of gas.

    Check_N_Build( UnitTypes::Zerg_Ultralisk_Cavern, drone, tech_starved &&
        Count_Units( UnitTypes::Zerg_Ultralisk_Cavern ) == 0 &&
        Count_Units( UnitTypes::Zerg_Hive ) >= 0 );

};
