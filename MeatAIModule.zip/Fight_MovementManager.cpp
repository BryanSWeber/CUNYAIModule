#pragma once

# include "Source\MeatAIModule.h"

using namespace BWAPI;
using namespace Filter;
using namespace std;

//Forces a unit to stutter in a brownian manner. Size of stutter is unit's (vision range * n ). Will attack if it sees something.  Overlords & lings stop if they can see minerals.
void MeatAIModule::Brownian_Stutter( Unit unit, double n, Unitset enemy_set ) {

    Position pos = unit->getPosition();
    Unitset neighbors = unit->getUnitsInRadius( 75, !IsEnemy );
    Unitset flock = unit->getUnitsInRadius( 1024, !IsWorker && IsOwned );

    double tot_x = 0;
    double tot_y = 0;
    double attune_dx = 0;
    double attune_dy = 0;
    double coh_dx = 0;
    double coh_dy = 0;
    double cen_dx = 0;
    double cen_dy = 0;
    double sep_dx = 0;
    double sep_dy = 0;
    int attract_dx = 0;
    int attract_dy = 0;
    double wlk_dx = 0;
    double wlk_dy = 0;
    double temp_wlk_dx = 0;
    double temp_wlk_dy = 0;

    // Stuttering, done randomly.
    double x_stutter = n * (rand() % 101 - 50) / 50 * unit->getType().sightRange();
    double y_stutter = n * (rand() % 101 - 50) / 50 * unit->getType().sightRange();// The naieve approach of rand()%3 - 1 is "distressingly non-random in lower order bits" according to stackoverflow and other sources.

    //Alignment.
    int flock_count = 0;
    if ( !flock.empty() ) {
        for ( auto i = flock.begin(); i != flock.end() && !flock.empty(); ++i ) {
            if ( (*i)->getType() != UnitTypes::Zerg_Drone && (*i)->getType() != UnitTypes::Zerg_Overlord ) {
                tot_x += cos( (*i)->getAngle() ); //get the horiz element.
                tot_y += sin( (*i)->getAngle() ); // get the vertical element. Averaging angles was trickier than I thought. 
                flock_count++;
            }
        }
        double theta = atan2( (tot_y - sin( unit->getAngle() ) ), (tot_x - cos( unit->getAngle() ) ) );  // subtract out the unit's personal heading.
        attune_dx = cos( theta ) * 0.40 * unit->getType().sightRange();
        attune_dy = sin( theta ) * 0.40 * unit->getType().sightRange();
        Diagnostic_Line( unit->getPosition(), { (int)(pos.x + attune_dx), (int)(pos.y + attune_dy) }, Colors::Green );
    }

    //Centraliziation         
        //Region r = unit->getRegion()
        //Region neighbor_r = r->getClosestAccessibleRegion();
        //Position center = neighbor_r->getCenter();
    Position center = { Broodwar->mapWidth() * 32 / 2, Broodwar->mapHeight() * 32 / 2 };
    double centralize_x = center.x - pos.x;
    double centralize_y = center.y - pos.y;
    double theta = atan2( centralize_y, centralize_x );
    cen_dx = cos( theta ) * 0.1 * unit->getType().sightRange();
    cen_dy = sin( theta ) * 0.1 * unit->getType().sightRange();
    Diagnostic_Line( unit->getPosition(), { (int)(pos.x + cen_dx), (int)(pos.y + cen_dy) }, Colors::Blue );

    //Cohesion
    if ( !flock.empty() ) {
            Position loc_center = flock.getPosition();
            Broodwar->drawCircleMap( loc_center, 5, Colors::Blue, true );
            double cohesion_x = loc_center.x - pos.x;
            double cohesion_y = loc_center.y - pos.y;
            double theta = atan2( cohesion_y, cohesion_x );
            coh_dx = cos( theta ) * 0.25 * unit->getType().sightRange();
            coh_dy = sin( theta ) * 0.25 * unit->getType().sightRange();
            Diagnostic_Line( unit->getPosition(), { (int)(pos.x + coh_dx), (int)(pos.y + coh_dy) }, Colors::Blue );
        }

    // Attraction towards attackable enemies (but no closer than 256, at which point combat logic will take over.)
    if ( !enemy_set.empty() && ( unit->getType().airWeapon() != WeaponTypes::None || unit->getType().groundWeapon() != WeaponTypes::None ) ) {

        Unit e = unit->getClosestUnit( IsEnemy );
        if ( unit->getType().airWeapon() == WeaponTypes::None && unit->getType().groundWeapon() != WeaponTypes::None ){
            e = unit->getClosestUnit( IsEnemy && !IsFlying );            

        }
        else if ( unit->getType().airWeapon() != WeaponTypes::None && unit->getType().groundWeapon() == WeaponTypes::None ) {
            e = unit->getClosestUnit( IsEnemy && IsFlying );
        }

        if ( e && e->exists() ) {
            int dist_x = e->getPosition().x - pos.x;
            int dist_y = e->getPosition().y - pos.y;
            double theta = atan2( dist_y, dist_x );
            if ( unit->getDistance( e ) > 256 ) {
                attract_dx = cos( theta ) * unit->getDistance( e ) * 0.15; // run X% towards them.  Must be enough to override the wander.
                attract_dy = sin( theta ) * unit->getDistance( e ) * 0.15;
            }
            Position retreat_spot = { pos.x + (int)attract_dx , pos.y + (int)attract_dy };
            Diagnostic_Line( unit->getPosition(), { pos.x + (int)attract_dx , pos.y + (int)attract_dy }, Colors::Red );
        }
    }

    // The following do NOT apply to flying units: Seperation, unwalkability.
    if ( !unit->getType().isFlyer() ) {
        //Seperation
        Position seperation = neighbors.getPosition();
        if ( seperation != pos ) { // don't seperate from yourself, that would be a disaster.
            double seperation_x = seperation.x - pos.x;
            double seperation_y = seperation.y - pos.y;
            double theta = atan2( seperation_y, seperation_x );
            sep_dx = cos( theta ) * 96; // run 3 tiles away from everyone minimum. Should help avoid being stuck in those wonky spots.
            sep_dy = sin( theta ) * 96;
            Diagnostic_Line( unit->getPosition(), { (int)(pos.x - sep_dx), (int)(pos.y - sep_dy) }, Colors::Orange );
        }

        //Push from unwalkability
        if ( !unit->isFlying() ) {
            for ( int x = -1; x <= 1; ++x ) {
                for ( int y = -1; y <= 1; ++y ) {
                    double walkability_x = pos.x + unit->getType().sightRange() * x;
                    double walkability_y = pos.y + unit->getType().sightRange() * y;
                    if ( !(x == 0 && y == 0) ) {
                        if ( walkability_x > Broodwar->mapWidth() * 32 || walkability_y > Broodwar->mapHeight() * 32 || // out of bounds by above map value.
                            walkability_x < 0 || walkability_y < 0 ||  // out of bounds by 0.
                            !Broodwar->isWalkable( (int)walkability_x / 8, (int)walkability_y / 8 ) ) { //Mapheight/width get map dimensions in TILES 1tile=32 pixels. Iswalkable gets it in minitiles, 1 minitile=8 pixels.
                            double theta = atan2( y, x );
                            temp_wlk_dx += cos( theta );
                            temp_wlk_dy += sin( theta );
                        }
                    }
                }
            }
        }
        if ( temp_wlk_dx != 0 && temp_wlk_dy != 0 ) {
            double theta = atan2( temp_wlk_dy, temp_wlk_dx );
            wlk_dx = cos( theta ) * unit->getType().sightRange() * 0.5;
            wlk_dy = sin( theta ) * unit->getType().sightRange() * 0.5;
            Diagnostic_Line( unit->getPosition(), { (int)(pos.x - wlk_dx), (int)(pos.y - wlk_dy) }, Colors::Purple );
        }
} // closure: flyers

    Position brownian_pos = { (int)(pos.x + x_stutter + coh_dx - sep_dx + attune_dx - wlk_dx + attract_dx + cen_dx ), (int)(pos.y + y_stutter + coh_dy - sep_dy + attune_dy - wlk_dy + attract_dy + cen_dy ) };

    if ( brownian_pos.isValid() ) {
        if ( unit->canAttack( brownian_pos ) && !army_starved) {
            unit->attack( brownian_pos );
        }
        else {
            unit->move( brownian_pos );
        }
    }

    if ( unit->getType() == UnitTypes::Zerg_Overlord || unit->getType() == UnitTypes::Zerg_Zergling ) {

        Unit min = unit->getClosestUnit( IsResourceContainer );
        Unitset bases = unit->getUnitsInRadius( UnitTypes::Zerg_Overlord.sightRange(), IsBuilding && IsOwned);
        Unitset e = unit->getUnitsInRadius( UnitTypes::Zerg_Overlord.sightRange(), IsEnemy );

    if ( min && min->exists() && bases.empty() && e.empty()) { // The closest unit aught to approach. Others need not bother.
            Unit best_unit = min->getClosestUnit();
            if ( best_unit && best_unit->exists() && unit == best_unit ) {
                Position center = min->getPosition();
                unit->move( center );
            }
        }
    }
};

// This is basic combat logic for nonspellcasting units.
void MeatAIModule::Tactical_Logic( Unit unit, Color color = Colors::White )
{
    UnitType u_type = unit->getType();
    int range_radius = u_type.airWeapon().maxRange() > u_type.groundWeapon().maxRange() ? u_type.airWeapon().maxRange() : u_type.groundWeapon().maxRange();
    int fighting_radius = 256 >  range_radius ? 256 : range_radius; // should use speed here.
    int priority = 0;
    int dist = 64;
    if ( range_radius ) {
        dist += range_radius;
    }

    Unitset enemies = unit->getUnitsInRadius( fighting_radius, IsEnemy );

    Unit target = unit->getClosestUnit(IsEnemy, fighting_radius); // default attack closest if this loop breaks or otherwise fails.

    for ( auto e = enemies.begin(); e != enemies.end() && !enemies.empty() ; ++e ) {

        UnitType e_type = (*e)->getType();
        int e_priority = 0;

        bool critical_target = e_type.groundWeapon().innerSplashRadius() > 0 ||
            ( e_type.isSpellcaster() && !e_type.isBuilding() ) ||
            (*e)->getHitPoints() < 0.25 * e_type.maxHitPoints() && Can_Fight( *e, unit ) ||
            (*e)->isRepairing() ||
            e_type == UnitTypes::Protoss_Reaver; // Prioritise these guys: Splash, caster, cloakers, crippled combat units, or repairing.

        if ( Can_Fight( unit, *e ) ) { // if we can fight this enemy:
            if ( critical_target ) { 
                e_priority = 3;
            }
            else if ( Can_Fight( *e, unit ) || e_type.spaceProvided() > 0 || (*e)->isAttacking() ) { // if they can fight us or carry troops
                e_priority = 2;
            }
            else {
                e_priority = 1; // or if they cant fight back we'll get those last.
            }
            if ( e_priority > priority || (e_priority == priority && unit->getDistance( *e ) <= dist) ) { // target the highest priority, then closest viable target.
                    priority = e_priority;
                    dist = unit->getDistance( *e );
                    target = (*e);
                }
            }
        }

    if ( target && target->exists() ) {
        unit->attack( target );
        Diagnostic_Line( unit->getPosition(), target->getPosition(), color );
    }

}

// Basic retreat logic, range = enemy range
void MeatAIModule::Retreat_Logic( Unit unit, Unit enemy, Color color = Colors::White ) {

    int dist = unit->getDistance( enemy );
    int air_range = enemy->getType().airWeapon().maxRange();
    int ground_range = enemy->getType().groundWeapon().maxRange();
    int range = air_range > ground_range ? air_range : ground_range;
    if ( dist < range + 100 ) { //  Run if you're a noncombat unit or army starved. +100 for safety. Retreat function now accounts for walkability.

        Position e_pos = enemy->getPosition();
        Region ret_region = enemy->getRegion()->getClosestAccessibleRegion();
        Position pos = unit->getPosition();
        Unitset neighbors = unit->getUnitsInRadius( 75 , !IsWorker && !IsBuilding && IsOwned );

        Broodwar->drawCircleMap( e_pos, range , Colors::Red );

        //initial retreat spot from enemy.
        int dist_x = e_pos.x - pos.x;
        int dist_y = e_pos.y - pos.y;
        double theta = atan2( dist_y, dist_x ); // att_y/att_x = tan (theta).
        double retreat_dx = -cos( theta ) * unit->getType().sightRange() ;
        double retreat_dy = -sin( theta ) * unit->getType().sightRange() ;

        ////initial retreat spot to nearest accessable region.
        //int dist_x = ret_region->getCenter().x - pos.x;
        //int dist_y = ret_region->getCenter().y - pos.y;
        //double theta = atan2( dist_y, dist_x ); // att_y/att_x = tan (theta).
        //double retreat_dx = cos( theta ) * unit->getType().sightRange();
        //double retreat_dy = sin( theta ) * unit->getType().sightRange();

        // Scatter- 
        double sep_dx = 0;
        double sep_dy = 0;
        if ( !unit->isFlying() ) {
            Position seperation = neighbors.getPosition();
            if ( seperation ) {
                double seperation_x = seperation.x - pos.x;
                double seperation_y = seperation.y - pos.y;
                double theta = atan2( seperation_y, seperation_x );
                sep_dx = cos( theta ) * 96;
                sep_dy = sin( theta ) * 96;
                Diagnostic_Line( unit->getPosition(), { (int)(pos.x - sep_dx), (int)(pos.y - sep_dy) }, Colors::Orange );
            }
        }

        // account for walkability.
        double wlk_dx = 0;
        double wlk_dy = 0;
        double temp_wlk_dx = 0;
        double temp_wlk_dy = 0;
        if ( !unit->isFlying() ) {
            for ( int x = -1; x <= 1; ++x ) {
                for ( int y = -1; y <= 1; ++y ) {
                    double walkability_x = pos.x + unit->getType().sightRange() * x;
                    double walkability_y = pos.y + unit->getType().sightRange() * y;
                    if ( !(x == 0 && y == 0) ) {
                        if ( walkability_x > Broodwar->mapWidth() * 32 || walkability_y > Broodwar->mapHeight() * 32 || // out of bounds by above map value.
                            walkability_x < 0 || walkability_y < 0 ||  // out of bounds by 0.
                            !Broodwar->isWalkable( (int)walkability_x / 8, (int)walkability_y / 8 ) ) { //Mapheight/width get map dimensions in TILES 1tile=32 pixels. Iswalkable gets it in minitiles, 1 minitile=8 pixels.
                            double theta = atan2( y, x );
                            temp_wlk_dx += cos( theta );
                            temp_wlk_dy += sin( theta );
                        }
                    }
                }
            }

            if ( temp_wlk_dx != 0 && temp_wlk_dy != 0 ) {
                double theta = atan2( temp_wlk_dy, temp_wlk_dx );
                wlk_dx = cos( theta ) * unit->getType().sightRange() * 1.25;
                wlk_dy = sin( theta ) * unit->getType().sightRange() * 1.25;
                Diagnostic_Line( unit->getPosition(), { (int)(pos.x - wlk_dx), (int)(pos.y - wlk_dy) }, Colors::Brown );
            }
        }
        Position retreat_spot = { pos.x + (int)retreat_dx - (int)wlk_dx -(int)sep_dx, pos.y + (int)retreat_dy - (int)wlk_dy - (int)sep_dy }; // the > < functions find the signum, no such function exists in c++!

        if ( retreat_spot && retreat_spot.isValid() ) {
            unit->move( retreat_spot ); //identify vector between yourself and e.  go 350 pixels away in the quadrant furthest from them.
            Diagnostic_Line( pos, retreat_spot, color );
        }
    }
}