#pragma once

#include <BWAPI.h>
#include "Source\MeatAIModule.h"
#include "Source\CobbDouglas.h"

using namespace std;

//complete but long creator method. Normalizes to 1 automatically.
CobbDouglas::CobbDouglas( double a_vis, double vis_ct, bool vision_cutoff, double a_army, double army_ct, bool army_cutoff, double a_tech, double tech_ct, bool tech_cutoff, double a_econ, double wk_ct, bool econ_cutoff )
{
    double a_tot = a_econ + a_vis + a_army + a_tech;

    alpha_econ = a_econ / a_tot;
    alpha_vis = a_vis / a_tot;
    alpha_army = a_army / a_tot;
    alpha_tech = a_tech / a_tot;

    worker_count = wk_ct;
    vision_tile_count = vis_ct;
    army_count = army_ct;
    tech_stock = tech_ct;

    econ_derivative = (alpha_econ / worker_count) * econ_cutoff;
    vision_derivative = (alpha_vis / vision_tile_count) * vision_cutoff;
    army_derivative = (alpha_army / army_count) * army_cutoff;
    tech_derivative = (alpha_tech / tech_stock) * tech_cutoff;

}

// Protected from failure in divide by 0 case.
double CobbDouglas::getlny()
{
    double ln_y = 0;
    try {
        double ln_y = alpha_vis * log( vision_tile_count / worker_count ) + alpha_army * log( army_count / worker_count ) + alpha_tech * log( tech_stock / worker_count );
    }
    catch ( ... ) {
        BWAPI::Broodwar->sendText( "Uh oh. We are out of something critical..." );
    };
    return ln_y;

}
// Protected from failure in divide by 0 case.
double CobbDouglas::getlnY()
{
    double ln_Y = 0;
    try {
        double ln_Y = alpha_vis * log( vision_tile_count ) + alpha_army * log( army_count ) + alpha_tech * log( tech_stock ) + alpha_econ * log( worker_count ); //Analog to GDP
    }
    catch ( ... ) {
        BWAPI::Broodwar->sendText( "Uh oh. We are out of something critical..." );
    };
    return ln_Y;
}
// Identifies the value of our main priority.
double CobbDouglas::getPriority() {
    double derivatives[4] = { econ_derivative, vision_derivative , army_derivative, tech_derivative };
    double priority = *(max_element( begin( derivatives ), end( derivatives ) ));
    return priority;
}

//Identifies priority type
bool CobbDouglas::army_starved()
{
    if ( army_derivative == getPriority() )
    {
        return true;
    }
    else {
        return false;
    }
}
//Identifies priority type
bool CobbDouglas::vision_starved()
{
    if ( vision_derivative == getPriority() )
    {
        return true;
    }
    else {
        return false;
    }
}
//Identifies priority type
bool CobbDouglas::econ_starved()
{
    if ( econ_derivative == getPriority() )
    {
        return true;
    }
    else {
        return false;
    }
}
//Identifies priority type
bool CobbDouglas::tech_starved()
{
    if ( tech_derivative == getPriority() )
    {
        return true;
    }
    else {
        return false;
    }
}
