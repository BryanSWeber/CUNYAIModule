#pragma once
// Remember not to use "Broodwar" in any global class constructor!
# include "Source\MeatAIModule.h"
# include <fstream>
# include <BWAPI.h>
# include <cstdlib>
# include <cstring>
# include <ctime>
# include <string>

using namespace BWAPI;
using namespace Filter;
using namespace std;

// Returns average of historical wins against that race for key heuristic values. For each specific value:[0...5] : { delta_out, gamma_out, a_army_out, a_vis_out, a_econ_out, a_tech_out };
double MeatAIModule::Win_History( string file, int value ) {
    ifstream input; // brings in info;
    input.open( file, ios::in );
    // for each row, m8
    
    string line;
    int csv_length = 0;
    while( std::getline( input, line ) ) {
        ++csv_length;
    }

        char row_char[20];
        double delta_in[5000];
        double gamma_in[5000];
        double a_army_in[5000];
        double a_vis_in[5000];
        double a_econ_in[5000];
        double a_tech_in[5000];
        string race_in[5000];
        int win_in[5000];
        int sdelay_in[5000];
        int mdelay_in[5000];
        int ldelay_in[5000];
        int seed_in[5000];


        for ( int j = 0; j < csv_length; ++j ) {
            for ( int i = 0; i < 13; ++i ) { // for each column in the row
                input.getline( row_char, 10, ',' );  // keeps the endline symbol unintentionally. Makes row_char a C-string, a null-terminated character array. Not a classic string.
                std::string entry = row_char;
                if ( !entry.empty() ) {
                    switch ( i )
                    {
                    case 1: delta_in[j] = stod( entry );
                    case 2: gamma_in[j] = stod( entry );
                    case 3: a_army_in[j] = stod( entry );
                    case 4: a_vis_in[j] = stod( entry );
                    case 5: a_econ_in[j] = stod( entry );
                    case 6: a_tech_in[j] = stod( entry );
                    case 7: race_in[j] = entry;
                    case 8: win_in[j] = stoi( entry );
                    case 9: sdelay_in[j] = stoi( entry );
                    case 10: mdelay_in[j] = stoi( entry );
                    case 11: ldelay_in[j] = stoi( entry );
                    case 12: seed_in[j] = stoi( entry );
                    } // closure switch
                }
            }// closure for each column in the row
        } // closure for each row

        // default values for output.
        double delta_out = 0.47;
        double gamma_out = 0.71;

        // the values below are normalized to 1.
        double a_army_out = 0.494;
        double a_vis_out =  0.494; 
        double a_econ_out = 0.01; 
        double a_tech_out = 0.002; 

        double delta_win[5000];
        double gamma_win[5000];
        double a_army_win[5000];
        double a_vis_win[5000];
        double a_econ_win[5000];
        double a_tech_win[5000];
        int win_count = 0;

        for ( int j = 0; j < csv_length; ++j ) {
            if ( (win_in[j] == 1 || sdelay_in[j] >=321 ) && race_in[j] == "Zerg" && Broodwar->enemy()->getRace() == Races::Zerg ) {
                delta_win[win_count] = delta_in[j];
                gamma_win[win_count] = gamma_in[j];
                a_army_win[win_count] = a_army_in[j];
                a_vis_win[win_count] = a_vis_in[j];
                a_econ_win[win_count] = a_econ_in[j];
                a_tech_win[win_count] = a_tech_in[j];
                win_count++;
            } else if ( (win_in[j] == 1 || sdelay_in[j] >= 321) && race_in[j] == "Protoss" && Broodwar->enemy()->getRace() == Races::Protoss ) {
                delta_win[win_count] = delta_in[j];
                gamma_win[win_count] = gamma_in[j];
                a_army_win[win_count] = a_army_in[j];
                a_vis_win[win_count] = a_vis_in[j];
                a_econ_win[win_count] = a_econ_in[j];
                a_tech_win[win_count] = a_tech_in[j];
                win_count++;
            } else if ( (win_in[j] == 1 || sdelay_in[j] >= 321) && race_in[j] == "Terran" && Broodwar->enemy()->getRace() == Races::Terran ) {
                delta_win[win_count] = delta_in[j];
                gamma_win[win_count] = gamma_in[j];
                a_army_win[win_count] = a_army_in[j];
                a_vis_win[win_count] = a_vis_in[j];
                a_econ_win[win_count] = a_econ_in[j];
                a_tech_win[win_count] = a_tech_in[j];
                win_count++;
            } else if ( (win_in[j] == 1 || sdelay_in[j] >= 321) && race_in[j] == "Random" && Broodwar->enemy()->getRace() == Races::Random ) {
                delta_win[win_count] = delta_in[j];
                gamma_win[win_count] = gamma_in[j];
                a_army_win[win_count] = a_army_in[j];
                a_vis_win[win_count] = a_vis_in[j];
                a_econ_win[win_count] = a_econ_in[j]; 
                a_tech_win[win_count] = a_tech_in[j];
                win_count++;
            }
        }

        if ( win_count != 0 ) { // redefine final output.

            int parent_1 = rand() % win_count + 1; // safe even if there is only 1 win.
            int parent_2 = rand() % win_count + 1;

            int chrom_0 = (rand() % 100 + 1) / 2;
            int chrom_1 = (rand() % 100 + 1) / 2;
            int chrom_2 = (rand() % 100 + 1) / 2;
            int chrom_3 = (rand() % 100 + 1) / 2;
            int chrom_4 = (rand() % 100 + 1) / 2;
            int chrom_5 = (rand() % 100 + 1) / 2;

            delta_out = chrom_0 > 50 ? delta_win[parent_1] : delta_win[parent_2]  ;
            gamma_out = chrom_1 > 50 ? gamma_win[parent_1] : gamma_win[parent_2] ;
            a_army_out = chrom_2 > 50 ? a_army_win[parent_1] : a_army_win[parent_2] ;
            a_vis_out = chrom_3 > 50 ? a_vis_win[parent_1] : a_vis_win[parent_2] ;
            a_econ_out = chrom_4 > 50 ? a_econ_win[parent_1] : a_econ_win[parent_2] ;
            a_tech_out = chrom_5 > 50 ? a_tech_win[parent_1] : a_tech_win[parent_2] ;
        }

        //From genetic history, random parent for each gene. Mutate the genome
        int mutation_1 = (rand() % 100 + 1) / 12.5;
        int mutation_2 = (rand() % 100 + 1) / 12.5; // rand int between 0-8
        int mutation_3 = (rand() % 100 + 1) / 12.5;

        delta_out = (mutation_1 == 0 || mutation_2 == 0 || mutation_3 == 0) ? delta_out * (rand() % 20 + 91) / (double)100 : delta_out;
        gamma_out = (mutation_1 == 0 || mutation_2 == 0 || mutation_3 == 0) ? gamma_out * (rand() % 20 + 91) / (double)100 : gamma_out;

        a_army_out = (mutation_1 == 0 || mutation_2 == 0 || mutation_3 == 0) ? a_army_out * (rand() % 100 + 51) / (double)100 : a_army_out;
        a_vis_out =  (mutation_1 == 0 || mutation_2 == 0 || mutation_3 == 0) ? a_vis_out  * (rand() % 100 + 51) / (double)100 : a_vis_out;
        a_econ_out = (mutation_1 == 0 || mutation_2 == 0 || mutation_3 == 0) ? a_econ_out * (rand() % 100 + 51) / (double)100 : a_econ_out;
        a_tech_out = (mutation_1 == 0 || mutation_2 == 0 || mutation_3 == 0) ? a_tech_out * (rand() % 100 + 51) / (double)100 : a_tech_out;

        double initial_cond[6] = { delta_out, gamma_out, a_army_out, a_vis_out, a_econ_out, a_tech_out };

        return initial_cond[value];
}