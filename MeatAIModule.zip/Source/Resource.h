#pragma once

#include <BWAPI.h>
#include "Worker.h"
#include "MeatAIModule.h"

class Resource : public BWAPI::UnitInterface {

private: 
    int _mincount=0;
    int _gascount=0;
    int _activeworkers=0;
    int _distbase=0;
    BWAPI::Position _location;

public:

    void setMoney( BWAPI::Unit r );
    void setDist( BWAPI::Unit r );
    void setResource( BWAPI::Unit r );

    void getWorker();
    int getMoney();
    int getActiveWorkers();
    int getDist();

};


