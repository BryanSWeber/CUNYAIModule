#pragma once

#include <BWAPI.h>
#include "Resource.h"
#include "MeatAIModule.h"

class Worker : public BWAPI::UnitInterface {

private:
    bool _gasworker = false;
    bool _minworker = false;
    bool _builder = false;
    BWAPI::Unit _attached_resource;
    BWAPI::Unit _attached_base;

public:
    void setWorker(BWAPI::Unit u);
    void setAttached_Resource( BWAPI::Unit r );
    void setAttached_Base( BWAPI::Unit base );
};
